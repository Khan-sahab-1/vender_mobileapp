// import React, { useState } from 'react';
// import {
//   View,
//   Text,
//   TextInput,
//   StyleSheet,
//   KeyboardAvoidingView,
//   Platform,
//   ScrollView,
// } from 'react-native';
// import ScreenContainer from '../../components/ScreenContainer';
// import Button from '../../components/Button';
// import { ErrorBanner } from '../../components/Feedback';
// import { useAuth } from '../../context/AuthContext';
// import { getErrorMessage } from '../../api/client';
// import { colors, radius, spacing, typography } from '../../theme/theme';

// export default function LoginScreen() {
//   const { login } = useAuth();
//   const [email, setEmail] = useState('admin@example.com');
//   const [password, setPassword] = useState('');
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState(null);

//   const handleLogin = async () => {
//     if (!email || !password) {
//       setError('Please enter both email and password');
//       return;
//     }
//     setLoading(true);
//     setError(null);
//     try {
//       await login(email.trim(), password);
//     } catch (e) {
//       setError(getErrorMessage(e));
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <ScreenContainer>
//       <KeyboardAvoidingView
//         style={{ flex: 1 }}
//         behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
//         <ScrollView
//           contentContainerStyle={styles.scroll}
//           keyboardShouldPersistTaps="handled">
//           <View style={styles.brand}>
//             <Text style={styles.brandIcon}>🗂️</Text>
//             <Text style={styles.brandTitle}>Erp</Text>
//             <Text style={styles.brandSubtitle}>Sign in to manage your business data</Text>
//           </View>

//           <ErrorBanner message={error} />

//           <View style={styles.form}>
//             <Text style={styles.label}>Email</Text>
//             <TextInput
//               value={email}
//               onChangeText={setEmail}
//               placeholder="you@example.com"
//               placeholderTextColor={colors.textMuted}
//               autoCapitalize="none"
//               keyboardType="email-address"
//               style={styles.input}
//             />

//             <Text style={styles.label}>Password</Text>
//             <TextInput
//               value={password}
//               onChangeText={setPassword}
//               placeholder="••••••••"
//               placeholderTextColor={colors.textMuted}
//               secureTextEntry
//               autoCapitalize="none"
//               style={styles.input}
//             />

//             <Button title="Sign In" onPress={handleLogin} loading={loading} style={{ marginTop: spacing.md }} />
//           </View>

//           <Text style={styles.hint}>
//             Default seeded admin: admin@example.com / Admin@123
//           </Text>
//         </ScrollView>
//       </KeyboardAvoidingView>
//     </ScreenContainer>
//   );
// }

// const styles = StyleSheet.create({
//   scroll: { flexGrow: 1, justifyContent: 'center', padding: spacing.lg },
//   brand: { alignItems: 'center', marginBottom: spacing.xl },
//   brandIcon: { fontSize: 48, marginBottom: spacing.sm },
//   brandTitle: { ...typography.h1, color: colors.text },
//   brandSubtitle: { ...typography.body, color: colors.textMuted, marginTop: spacing.xs },
//   form: { marginTop: spacing.sm },
//   label: { ...typography.h3, color: colors.text, marginBottom: spacing.xs, marginTop: spacing.sm },
//   input: {
//     backgroundColor: colors.surface,
//     borderWidth: 1,
//     borderColor: colors.border,
//     borderRadius: radius.sm,
//     paddingHorizontal: spacing.sm,
//     paddingVertical: spacing.sm,
//     color: colors.text,
//     ...typography.body,
//   },
//   hint: {
//     ...typography.caption,
//     color: colors.textMuted,
//     textAlign: 'center',
//     marginTop: spacing.xl,
//   },
// });


import React, { useEffect, useRef, useState } from 'react';
import {
  Animated,
  ActivityIndicator,
  Easing,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useAuth } from '../../context/AuthContext';
import { getErrorMessage } from '../../api/client';

/* ------------------------------------------------------------------ *
 * Design tokens (local to this screen so nothing else in the app breaks)
 * Ink + indigo for trust, one amber bar as the single memorable accent.
 * ------------------------------------------------------------------ */
const C = {
  ink: '#12163A',
  inkSoft: '#2A3070',
  indigo: '#4353F0',
  indigoPressed: '#3543D6',
  amber: '#FFB63D',
  sheet: '#FFFFFF',
  field: '#F4F6FC',
  border: '#DCE1F0',
  text: '#12163A',
  muted: '#6B7297',
  onInk: '#FFFFFF',
  onInkMuted: '#AEB4E0',
  errorBg: '#FFF0F0',
  errorBorder: '#F5B5B5',
  errorText: '#B42323',
};

const BARS = [0.38, 0.6, 0.48, 0.82, 1];

/* ------------------------- Hero illustration ------------------------ */
function LedgerBars() {
  const progress = useRef(BARS.map(() => new Animated.Value(0))).current;

  useEffect(() => {
    // The one orchestrated motion on this screen: bars rise once on load.
    Animated.stagger(
      90,
      progress.map((v) =>
        Animated.timing(v, {
          toValue: 1,
          duration: 700,
          easing: Easing.out(Easing.cubic),
          useNativeDriver: false,
        }),
      ),
    ).start();
  }, [progress]);

  return (
    <View
      style={styles.bars}
      accessibilityElementsHidden
      importantForAccessibility="no-hide-descendants">
      {BARS.map((h, i) => {
        const isLast = i === BARS.length - 1;
        return (
          <Animated.View
            key={i}
            style={[
              styles.bar,
              {
                backgroundColor: isLast ? C.amber : C.inkSoft,
                height: progress[i].interpolate({
                  inputRange: [0, 1],
                  outputRange: [6, 84 * h],
                }),
              },
            ]}
          />
        );
      })}
    </View>
  );
}

/* ---------------------------- Text field ---------------------------- */
const Field = React.forwardRef(function Field(
  { label, right, style, ...inputProps },
  ref,
) {
  const [focused, setFocused] = useState(false);
  return (
    <View style={style}>
      <Text style={styles.label}>{label}</Text>
      <View
        style={[
          styles.inputWrap,
          focused && styles.inputWrapFocused,
        ]}>
        <TextInput
          ref={ref}
          style={styles.input}
          placeholderTextColor="#9AA0C4"
          selectionColor={C.indigo}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          accessibilityLabel={label}
          {...inputProps}
        />
        {right}
      </View>
    </View>
  );
});

/* ------------------------- Primary button --------------------------- */
function PrimaryButton({ title, onPress, loading, disabled }) {
  const scale = useRef(new Animated.Value(1)).current;
  const animate = (to) =>
    Animated.spring(scale, {
      toValue: to,
      speed: 40,
      bounciness: 0,
      useNativeDriver: true,
    }).start();

  const inactive = disabled || loading;

  return (
    <Animated.View style={{ transform: [{ scale }] }}>
      <Pressable
        onPress={onPress}
        onPressIn={() => animate(0.97)}
        onPressOut={() => animate(1)}
        disabled={inactive}
        accessibilityRole="button"
        accessibilityState={{ disabled: inactive, busy: loading }}
        style={({ pressed }) => [
          styles.button,
          pressed && { backgroundColor: C.indigoPressed },
          inactive && styles.buttonInactive,
        ]}>
        {loading ? (
          <ActivityIndicator color={C.onInk} />
        ) : (
          <Text style={styles.buttonText}>{title}</Text>
        )}
      </Pressable>
    </Animated.View>
  );
}

/* ------------------------------ Screen ------------------------------ */
export default function LoginScreen() {
  const { login } = useAuth();

  // Seeded credentials only pre-filled in development builds.
  const [email, setEmail] = useState(__DEV__ ? 'admin@example.com' : '');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const passwordRef = useRef(null);
  const shake = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!error) return;
    Animated.sequence([
      Animated.timing(shake, { toValue: 8, duration: 60, useNativeDriver: true }),
      Animated.timing(shake, { toValue: -8, duration: 60, useNativeDriver: true }),
      Animated.timing(shake, { toValue: 5, duration: 60, useNativeDriver: true }),
      Animated.timing(shake, { toValue: 0, duration: 60, useNativeDriver: true }),
    ]).start();
  }, [error, shake]);

  const handleLogin = async () => {
    if (loading) return;
    if (!email.trim() || !password) {
      setError('Enter your email and password to sign in.');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      await login(email.trim(), password);
    } catch (e) {
      setError(getErrorMessage(e));
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" backgroundColor={C.ink} />
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView
          contentContainerStyle={styles.scroll}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
          bounces={false}>
          {/* Hero */}
          <View style={styles.hero}>
            <View style={styles.brandRow}>
              <View style={styles.logo}>
                <Text style={styles.logoLetter}>E</Text>
              </View>
              <Text style={styles.brandName}>Erp</Text>
            </View>

            <Text style={styles.headline}>
              Your whole business,{'\n'}in one place.
            </Text>
            <Text style={styles.subhead}>
              Stock, sales and accounts, always up to date.
            </Text>

            <LedgerBars />
          </View>

          {/* Sheet */}
          <View style={styles.sheet}>
            <Text style={styles.title}>Sign in</Text>
            <Text style={styles.caption}>
              Use the account your administrator created for you.
            </Text>

            {error ? (
              <Animated.View
                style={[styles.error, { transform: [{ translateX: shake }] }]}
                accessibilityRole="alert">
                <Text style={styles.errorText}>{error}</Text>
              </Animated.View>
            ) : null}

            <Field
              label="Email"
              value={email}
              onChangeText={setEmail}
              placeholder="you@company.com"
              autoCapitalize="none"
              autoCorrect={false}
              keyboardType="email-address"
              textContentType="username"
              autoComplete="email"
              returnKeyType="next"
              onSubmitEditing={() => passwordRef.current?.focus()}
              blurOnSubmit={false}
              style={styles.fieldGap}
            />

            <Field
              ref={passwordRef}
              label="Password"
              value={password}
              onChangeText={setPassword}
              placeholder="Enter your password"
              secureTextEntry={!showPassword}
              autoCapitalize="none"
              autoCorrect={false}
              textContentType="password"
              autoComplete="password"
              returnKeyType="go"
              onSubmitEditing={handleLogin}
              style={styles.fieldGap}
              right={
                <Pressable
                  onPress={() => setShowPassword((s) => !s)}
                  hitSlop={12}
                  accessibilityRole="button"
                  accessibilityLabel={showPassword ? 'Hide password' : 'Show password'}>
                  <Text style={styles.toggle}>{showPassword ? 'Hide' : 'Show'}</Text>
                </Pressable>
              }
            />

            <View style={styles.buttonGap}>
              <PrimaryButton
                title="Sign in"
                onPress={handleLogin}
                loading={loading}
              />
            </View>

            {__DEV__ ? (
              <Text style={styles.devHint}>
                Dev build · admin@example.com / Admin@123
              </Text>
            ) : null}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

/* ------------------------------ Styles ------------------------------ */
const styles = StyleSheet.create({
  flex: { flex: 1 },
  root: { flex: 1, backgroundColor: C.ink },
  scroll: { flexGrow: 1 },

  hero: {
    paddingTop: Platform.OS === 'ios' ? 72 : 56,
    paddingHorizontal: 28,
    paddingBottom: 44,
  },
  brandRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 36 },
  logo: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: C.indigo,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoLetter: { color: C.onInk, fontSize: 22, fontWeight: '800' },
  brandName: {
    color: C.onInk,
    fontSize: 20,
    fontWeight: '700',
    marginLeft: 12,
    letterSpacing: 0.3,
  },
  headline: {
    color: C.onInk,
    fontSize: 32,
    lineHeight: 38,
    fontWeight: '800',
    letterSpacing: -0.6,
  },
  subhead: {
    color: C.onInkMuted,
    fontSize: 15,
    lineHeight: 22,
    marginTop: 12,
    maxWidth: 300,
  },
  bars: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    height: 84,
    marginTop: 32,
  },
  bar: { width: 26, borderRadius: 8, marginRight: 10 },

  sheet: {
    flexGrow: 1,
    backgroundColor: C.sheet,
    borderTopLeftRadius: 32,
    borderTopRightRadius: 32,
    paddingHorizontal: 28,
    paddingTop: 32,
    paddingBottom: 40,
  },
  title: {
    color: C.text,
    fontSize: 24,
    fontWeight: '800',
    letterSpacing: -0.3,
  },
  caption: { color: C.muted, fontSize: 14, lineHeight: 20, marginTop: 6 },

  error: {
    backgroundColor: C.errorBg,
    borderWidth: 1,
    borderColor: C.errorBorder,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    marginTop: 20,
  },
  errorText: { color: C.errorText, fontSize: 14, lineHeight: 20 },

  fieldGap: { marginTop: 20 },
  label: {
    color: C.text,
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 8,
  },
  inputWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: C.field,
    borderWidth: 1.5,
    borderColor: C.border,
    borderRadius: 14,
    paddingHorizontal: 16,
    height: 54,
  },
  inputWrapFocused: {
    borderColor: C.indigo,
    backgroundColor: C.sheet,
  },
  input: { flex: 1, color: C.text, fontSize: 16, paddingVertical: 0 },
  toggle: { color: C.indigo, fontSize: 14, fontWeight: '700', marginLeft: 12 },

  buttonGap: { marginTop: 28 },
  button: {
    height: 56,
    borderRadius: 16,
    backgroundColor: C.indigo,
    alignItems: 'center',
    justifyContent: 'center',
    ...Platform.select({
      ios: {
        shadowColor: C.indigo,
        shadowOpacity: 0.35,
        shadowRadius: 16,
        shadowOffset: { width: 0, height: 8 },
      },
      android: { elevation: 6 },
    }),
  },
  buttonInactive: { opacity: 0.7 },
  buttonText: {
    color: C.onInk,
    fontSize: 17,
    fontWeight: '700',
    letterSpacing: 0.2,
  },

  devHint: {
    color: C.muted,
    fontSize: 12,
    textAlign: 'center',
    marginTop: 24,
  },
});