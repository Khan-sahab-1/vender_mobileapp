import client from './client';

export const authApi = {
  login: async (email, password) => {
    const { data } = await client.post('/auth/login', { email, password });
    return data; // { accessToken, user }
  },
  me: async () => {
    const { data } = await client.get('/users/me');
    return data;
  },
};
